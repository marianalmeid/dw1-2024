let numero = 10

if (numero % 2 == 0){
    console.log('O número ${numero} é par')
}