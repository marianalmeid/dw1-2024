function countVowels(str){
    let count = 0
    for (let letra of str){
        if ('aeiouAEIOU'.includes(letra)){
            count += 1
        }
    }
    return count
}

console.log(countVowels("OpenAI")); // Deve exibir: 4
console.log(countVowels("JavaScript")); // Deve exibir: 3