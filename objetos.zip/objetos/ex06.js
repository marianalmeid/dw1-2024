const biblioteca ={
    titulo: ['1984', 'Dom Casmurro', 'As Crônicas de Nárnia'],
    autor: ['George Orwell', 'Machado de Assis', 'CS Lewis'],
    ano: [1949, 1899, 1950]
}
console.log(biblioteca.titulo)