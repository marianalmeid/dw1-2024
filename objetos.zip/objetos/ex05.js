const produto ={
    nome: 'caneta',
    preco: 2,
    categoria: 'escolar'
}
for (i in produto){
    console.log(i,':', produto[i])
}