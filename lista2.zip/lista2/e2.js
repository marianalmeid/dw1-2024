function decrescente(N) {
    for (let i = N; i >= 1; i--) {
        console.log(i);
    }
}

decrescente(5); 
