function crescente(N) {
    for (let i = 1; i <= N; i++) {
        console.log(i);
    }
}

crescente(5);
